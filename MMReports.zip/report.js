$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("verifyAndAdd.feature");
formatter.feature({
  "line": 1,
  "name": "TotalBalanceTable",
  "description": "",
  "id": "totalbalancetable",
  "keyword": "Feature"
});
formatter.before({
  "duration": 327530,
  "status": "passed"
});
formatter.scenario({
  "line": 2,
  "name": "Open assessment page and verify values",
  "description": "",
  "id": "totalbalancetable;open-assessment-page-and-verify-values",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "I have open the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 4,
  "name": "I open the Mass Mutual Assessment URL",
  "keyword": "When "
});
formatter.step({
  "line": 5,
  "name": "Verify the right count of values appear on the screen",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "Verify the values are formatted as currencies",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "Verify the values on the screen are greater than 0",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "Verify the total balance is correct based on the values listed on the screen",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "Verify the total balance matches the sum of the values",
  "keyword": "And "
});
formatter.match({
  "location": "VerifyAndAddSteps.openBrowser()"
});
formatter.result({
  "duration": 1412624878,
  "status": "passed"
});
formatter.match({
  "location": "VerifyAndAddSteps.goToMassMutualAssessmentPage()"
});
formatter.result({
  "duration": 215640446,
  "status": "passed"
});
formatter.match({
  "location": "VerifyAndAddSteps.rightCount()"
});
formatter.result({
  "duration": 203559981,
  "status": "passed"
});
formatter.match({
  "location": "VerifyAndAddSteps.currencyFormat()"
});
formatter.result({
  "duration": 89315250,
  "status": "passed"
});
formatter.match({
  "location": "VerifyAndAddSteps.greaterThanZero()"
});
formatter.result({
  "duration": 78207508,
  "status": "passed"
});
formatter.match({
  "location": "VerifyAndAddSteps.correctBalance()"
});
formatter.result({
  "duration": 45424355,
  "status": "passed"
});
formatter.match({
  "location": "VerifyAndAddSteps.totalBalance()"
});
formatter.result({
  "duration": 42632749,
  "status": "passed"
});
formatter.after({
  "duration": 127613099,
  "status": "passed"
});
});